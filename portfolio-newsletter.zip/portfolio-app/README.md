# 📬 Portföljnyhetsbrev

Automatisk kurshämtning + AI-genererat nyhetsbrev med Claude.

---

## Driftsättning på Vercel (steg för steg)

### Steg 1 — Ladda upp koden till GitHub

1. Gå till **github.com** och logga in
2. Klicka på **"+"** uppe till höger → **"New repository"**
3. Namnge det `portfolio-newsletter`
4. Klicka **"Create repository"**
5. På nästa sida, klicka **"uploading an existing file"**
6. Dra och släpp HELA mappen `portfolio-app` (alla filer)
7. Klicka **"Commit changes"**

### Steg 2 — Koppla till Vercel

1. Gå till **vercel.com** och logga in med GitHub
2. Klicka **"Add New Project"**
3. Välj ditt `portfolio-newsletter` repository
4. Klicka **"Deploy"** — Vercel bygger appen automatiskt

### Steg 3 — Lägg till din API-nyckel

1. I Vercel, gå till ditt projekt → **"Settings"** → **"Environment Variables"**
2. Klicka **"Add New"**
3. Name: `ANTHROPIC_API_KEY`
4. Value: din nyckel (börjar med `sk-ant-...`)
5. Klicka **"Save"**
6. Gå till **"Deployments"** → klicka **"Redeploy"**

### Klart! 🎉

Din app finns nu på en URL som ser ut som:
`https://portfolio-newsletter-xxx.vercel.app`

---

## Hur du använder appen

1. Öppna appen i webbläsaren
2. Tryck **"Hämta kurser"** — hämtar live-kurser för alla 26 innehav
3. Tryck **"Generera nyhetsbrev"** — tar 1–2 minuter
4. Tryck **"Kopiera"** och klistra in var du vill

---

## Kostnad

- **Vercel:** Gratis
- **Anthropic API:** ~$0.50–1.50 per nyhetsbrev beroende på längd
